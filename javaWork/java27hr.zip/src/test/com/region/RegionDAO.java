package test.com.region;

import java.util.List;

public interface RegionDAO {
	public List<RegionVO> selectAll();
}
